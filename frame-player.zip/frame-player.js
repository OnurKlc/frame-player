let playStatus = "paused";

const play = () => {
    playStatus = "playing";
    t = setInterval(bgHandler, 100);
};

const pause = () => {
    playStatus = "paused";
    clearInterval(t);
}

const playpause = () => {
    if (playStatus === "playing") {
        pause();
    }
    else if (playStatus === "paused") {
        play();
    }
}

var x = 0;
var y = 0;
var z = 0;
var i = 0;
const bgHandler = () => {
    x = x + 25;
    if (x > 100) {
        x = 0;
        y = y + 25;
    }
    if (y > 100) {
        i++;
        if (i >= 7) {
            clearInterval(t);
            x = 100;
            y = 100;
        }else {
            document.getElementById("player").style.backgroundImage = `url("http://storage.googleapis.com/alyo/assignments/images/${i}.jpg")`;
            x = 0;
            y = 0;        
        }
    }
    document.getElementById("player").style.backgroundPosition = x + "% " + y + "%";

    if (z < 99.9999999999998) {
        z += 100 / 175;
    }
    document.getElementById("progressBar").style.width = z + "%";
};

const seekAndDestroy = () => {

}


// get images
    
    for (let i = 0; i < 7; i++) {
    var request = new XMLHttpRequest();
    request.open('GET', `http://storage.googleapis.com/alyo/assignments/images/${i}.jpg`);
    request.send();
    request.onload = function(response) {
        if (request.status !== 200) {
            alert(`Error ${request.status}: ${request.statusText}`);
        }
        else {
            console.log(response);
            var image = document.createElement("img");
        }
    }

    request.onprogress = function(event) {
    // if (event.lengthComputable) {
    //   alert(`Received ${event.loaded} of ${event.total} bytes`);
    // } else {
    //   alert(`Received ${event.loaded} bytes`); // no Content-Length
    // }
    };
    }

    request.onerror = function() {
        alert("Request failed");
    };
